/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Q1;

import javax.swing.JOptionPane;

/**
 *
 * @author Future CEO
 */
//1.3 example of an of else statement
public class Purchase {
   
    public static void main(String[]args){
        //ask user for their budget
        
String input = JOptionPane.showInputDialog("Please enter your budget:");
       
int budget = Integer.parseInt(input);
    //check if budget is enough for purchase order
    if(budget>=100) {
         JOptionPane.showMessageDialog(null,"Your order can be succesfully purchased");
        
        } else{ 
            JOptionPane.showMessageDialog(null," Unfortuanately your order can not be processed");
        }
       
    }
}
