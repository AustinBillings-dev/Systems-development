/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Q1;
//1.2 example of an if statement
import java.util.Scanner;

public class Weight{
      
public static void main(String[]args){
    
Scanner input = new Scanner(System.in);
//ask trainee for their weight
System.out.println("Please enter your average weight:");

int weight = input.nextInt();
//check if trainee weighs over 30
if(weight>=30){
System.out.println("You are required to join our training sessions.");}
}
}
 
