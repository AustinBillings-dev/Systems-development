/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Q3;

/**
 *
 * @author Future CEO
 */
//Question 3.1 
public class LibrarySystem{
        public static void main(String[]args){

            Book[]books = new Book[5];
      books[0]= new Book("Java Programming","John Smith");
      books[1]= new Book("Data Structures","Alice Johnson");
      books[2]= new Book("Machine Learning","David Williams");
      books[3]= new Book("Algorithms","Emily Davis");
      books[4]= new Book("Web Development","Micheal Brown");
            for (int i = 0 ; i < books.length; i++){
                System.out.println(books[i].getTitle() + " : " + " by " + books[i].getAuthor());
            }
        }
    
}