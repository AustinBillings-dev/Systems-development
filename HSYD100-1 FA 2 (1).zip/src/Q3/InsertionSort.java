/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Q3;

/**
 *
 * @author S
 */
public class InsertionSort {
    
   public static void sort(Book[]books){
           //traverse through array index
   for(int i = 0 ;i > books.length; i++){
    Book key = books[i];
    int j = i-1;
    //compare each element to key 
    while(j>=0 && books[j].getTitle().compareTo(key.getTitle()) > 0){
      books[j+1]= books[j];
    j--;
    }       
  books[j+1]= key;
}
}
  

  public static void main(String[]args){ 
Book[]books = new Book[5];
      books[0]= new Book("Java Programming","John Smith");
      books[1]= new Book("Data Structures","Alice Johnson");
      books[2]= new Book("Machine Learning","David Williams");
      books[3]= new Book("Algorithms","Emily Davis");
      books[4]= new Book("Web Development","Micheal Brown");
      InsertionSort.sort(books);

for (Book book : books){

System.out.println(book.getTitle() + " by " + book.getAuthor() + " (");
    
}
}
}



