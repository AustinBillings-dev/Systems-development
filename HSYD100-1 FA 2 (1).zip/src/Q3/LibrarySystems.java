/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Q3;

import java.util.Scanner;

/**
 *
 * @author S
 */
public class LibrarySystems {
 // question 3.2 searching an array   
        
public static void main(String[]args){

Book[]books = new Book[5];
      books[0]= new Book("Java Programming","John Smith");
      books[1]= new Book("Data Structures","Alice Johnson");
      books[2]= new Book("Machine Learning","David Williams");
      books[3]= new Book("Algorithms","Emily Davis");
      books[4]= new Book("Web Development","Micheal Brown");
      sortBooksByTitle(books);

    for (Book book : books) {
        System.out.println(book.getTitle() + book.getAuthor() + "Title: ");
    }
Scanner input = new Scanner(System.in);
System.out.println("Enter the book titile of choice");
String targetTitle = input.nextLine();
int index = searchBook(books , targetTitle);
if (index != -1){
System.out.println("Book requested found at index" + index);
} else { 
System.out.println("-1");
}
}

public static int searchBook(Book[]books, String targetTitle){
for (int i = 0; i < books.length; i++) {
if (books[i].getTitle().equals(targetTitle)){
return i;
}

}
return -1; //if book not found
}
public static void sortBooksByTitle(Book[] books ){
for (int i = 1 ; i < books.length; i++){
Book key = books [i];
int j = i - 1;

while (j >= 0 && books[j].getTitle().compareTo(key.getTitle()) > 0){

books[j+1] = books[j];
j--;
}
books[j+1]= key;
}
}
}

    



