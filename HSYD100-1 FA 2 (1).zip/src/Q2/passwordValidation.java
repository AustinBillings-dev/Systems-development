/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Q2;

import java.util.Scanner;

/**
 *
 * @author Future CEO
 */
public class passwordValidation {

    private static int UpperCount;
    

  //QUESTION 2.1 
   
   public static void main(String[]args){
        
       String password;
               
        Scanner input = new Scanner(System.in);
               System.out.println("Please enter your password:");
         password = input.nextLine();
              
               boolean containsSpecialChar = false;
       for(int i = 0;i < password.length();i++){
           char ch= password.charAt(i);
           
           if (!Character.isLetterOrDigit(ch)){
              containsSpecialChar = true;
           break;
           } 
       }
               if(containsSpecialChar){
                   System.out.println("Password Accepted");
               } else{ 
                   System.out.println("Password must contain at least once special character");
               }
               
           }
       }
    

