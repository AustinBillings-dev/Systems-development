package SourceCode;
import java.lang.reflect.Method;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Future CEO
 */
public class Book {
    
 public String title;
 public String author;

   
 public String getTitle() {
 return title;
 }
 public void setTitle(String title) {
 this.title = title;
 }
 public String getAuthor() {
 return author;
 }
 public void setAuthor(String author) {
 this.author = author;
 }
public Book(String title, String author) {
 this.title = title;
 this.author = author;
 }
 
 
 }//end class book

 

