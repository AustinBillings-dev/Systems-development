/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SourceCode;
import javax.swing.JOptionPane;
/**
 *
 * @author Future CEO
 */

public class RegistrationSystem {
      public static void main(String[] args)
    {
     // display the results of the password validification//
     String pass = JOptionPane.showInputDialog("Enter password here: ");
     System.out.println(validation(pass));       
    }

    public static String validation(String password) 
    {
//variable declaration//
        int stLength;
        boolean check;
        boolean conA;
        int i;

// variable assighment//
        stLength= password.length();
 
// for loop to separate the substring//
        
           for(i=0; i<=stLength;++i)
           { 
            
            char ch = password.charAt(i);
            boolean conC = (Character.isLetter(ch));
            conA = (Character.isDigit(ch));
            check = conC || conA;
            System.out.println("conC: " +conC);
            System.out.println("conA: " +conA);
            
     
        System.out.println("Total: " +check);
              if (check){
                  return "Password must contain atleast one special character.";
              } else{ 
                  return "Password Accepted";
              }
           }
          }
    
/// end of method validification///
    
   }
