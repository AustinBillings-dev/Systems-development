package SourceCode;
import javax.swing.JOptionPane;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Future CEO
 */

public class LibrarySystem {
         //String input = JOptionPane.showInputDialog("");
         Scanner userInput = new Scanner(System.in);
         String input = userInput.nextLine();

    
   public static void main(String[] args) {
   Book[] books = new Book[5];
   books[0] = new Book("Java Programming", "John Smith");
   books[1] = new Book("Data Structures", "Alice Johnson");
   books[2] = new Book("Machine Learning", "David Williams");
   books[3] = new Book("Algorithms", "Emily Davis");
   books[4] = new Book("Web Development", "Michael Brown");
   
////////////////////// question 3.1 source code//////////////////////////////
   int res = 0;
   while(res < 5)
   {
   System.out.println(books[res].title + " by "+ books[res].author);
   ++res;
   }
  
             searchBook(books,input);

 }///end main method///
    
    /**
     *
     * @param books
     * @param title
     * @return
     */
    public int searchBook(Book[] books, String title)
   {
       int x =0;
       while(x <= books.length)
       {
           Book.class.cast(books)
          if(books[x].title.equals(title))
          {
              return x;
          }else{
              return -1;
          }
       }
       
   }
    
    
    
    
}
