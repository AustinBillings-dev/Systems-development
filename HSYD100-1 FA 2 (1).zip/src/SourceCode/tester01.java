/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SourceCode;

/**
 *
 * @author Future CEO
 */
public class tester01 {
    public static void main(String[] args){
   
    
    }
