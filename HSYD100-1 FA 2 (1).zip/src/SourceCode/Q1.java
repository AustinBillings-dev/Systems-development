/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SourceCode;

import javax.swing.JOptionPane;

/**
 *
 * @author Future CEO
 */
public class Q1 {
     public static void main(String[] args) {
         
// user input variable//
      String input = JOptionPane.showInputDialog("enter the stock total: ");
      int xl = Integer.parseInt(input);
        
///////////////////////////////// 1.2 source code //////////////////////////////
        if(xl >= 1) //the if statement notifys users wether xl T-shirts are in stock
        {
            System.out.println("if-statement 1: We still have some in stock");
        }
       
/////////////////////////////// 1.3 source code ////////////////////////////////
        if(xl >= 1) //the if statement notifys users wether xl T-shirts are in stock
        {
            System.out.println("if-statement 2: We still have some in stock");
        } else{ 
            System.out.println("if-statement 2: we are out of stock");
        }
   
     }
}
