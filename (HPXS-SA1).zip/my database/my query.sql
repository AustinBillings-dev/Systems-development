create database City_Cyclists_Challenge2;

use City_Cyclists_Challenge2;

create table Teams(
team_id Int Not null Auto_increment,
team_name Varchar(100),
Primary key (team_id)
);

Create table Participants(
participant_id Int Auto_Increment Not Null,
first_name Varchar(100),
last_name Varchar(100),
age Int ,
contact_number Varchar(20),
Category Enum('Amateur','Professional'),
registration_date Date,
team_id Int,
Primary key(participant_id),
Foreign key(team_id) References Teams(team_id)
);

create table Registration_packages(
reg_package_id Int Not Null Auto_Increment,
reg_package_name Varchar(100),
package_description Text ,
price Decimal(10,2),
Primary key(reg_package_id)
);

create table Participant_packages(
participant_package_id Int Not Null Auto_Increment,
participant_id Int,
reg_package_id Int,
date_selected date,
Primary key (participant_package_id),
Foreign key (participant_id) References Participants(participant_id),
Foreign key (reg_package_id) References Registration_packages(reg_package_id)
);

create table Payments(
payment_id Int Not Null Auto_Increment,
participant_id Int,
team_id Int,
amount Decimal(10,2),
payment_status ENUM('Payment Pending','Payment Completed','Payment Failed'),
payment_date Date,
Primary key(payment_id),
Foreign key (participant_id) References Participants(participant_id),
Foreign key(team_id) References Teams(team_id)
);
create table Communications(
message_id Int Not null Auto_increment,
participant_id Int,
message_subject Varchar(100),
message_type ENUM('Confirmation','Update','Reminder'),
date_sent Date,
Primary key (message_id),
Foreign key (participant_id) References Participants(participant_id)
);
create table Event_documents(
document_id Int Not null Auto_increment,
document_title Varchar(100),
upload_date Date,
file Varchar(100),
Primary key(document_id)
);

Insert INTO Teams(team_name)
Values ('Hustlers'),('Players'),('Toppies'),('Mzansi'),('Ballers');

Insert INTO Participants(first_name, last_name, age, contact_number, category, registration_date, team_id)
Values ('Austin','Billings', 21,'0683304886','Professional','2025-01-30', 1),
('Bones','Boss', 50,'0899467888', 'Professional','2025-01-30', 2), ('Jess','Adams',20,'0744444444','Amateur','2025-01-30', 3),
('Yoland', 'Queen', 39 ,'0899901234','Amateur','2025-01-30', 4), ('Waka', 'Yster', 28, '0811142121','Professional','2025-01-30', 5);

Insert INTO Registration_packages(reg_package_name, package_description, price)
Values ('Premium plus package', 'Entry with meals, merchandise & maintenance', 250.00),('Premium package','Entry with meals & merchandise',200.00)
,('Custom package', 'Flexible options', 150.00),('Special package', 'Entry with a meal',95.00),('Basic package','Entry only',50.00);

Insert INTO Participant_packages(participant_id, reg_package_id , date_selected)
Values (1, 4, '2025-04-10'),(2,  2, '2025-04-10'),(3,  3, '2025-04-11'),(4,  5, '2025-04-12'),(5,  1, '2025-04-12');

Insert INTO Payments(participant_id, amount, payment_status)
Values(5, 250.00, 'Payment Pending'),(4, 150.00, 'Payment Pending'),(3, 200.00, 'Payment Completed'),(2, 95.00, 'Payment Completed'),(1, 50.00, 'Payment Failed');

Insert INTO Communications(participant_id, message_subject, message_type)
Values(1, 'Team Package reserved', 'Update'), (2, 'Pending payment', 'Reminder'), (4, 'Insufficient Payment ', 'Update'), (3, 'Approved payment', 'Confirmation')
,(5, 'Package reserved', 'Confirmation');

Insert INTO Event_documents(document_title, file, upload_date)
Values('Event statistics','event stats.pdf','2025-05-10'),('Event route map','route map.pdf','2025-01-30'),('Event safety precautions','event safety.pdf','2025-02-20'),
('event schedule','schedule.pdf','2025-01-30') , ('Event payment packages','event packages.pdf','2025-01-30');


SELECT * FROM Teams;
SELECT * FROM Participants;
SELECT * FROM Registration_packages;
SELECT * FROM Participant_packages;
SELECT * FROM Payments;
SELECT * FROM Communications;
SELECT * FROM Event_documents;

