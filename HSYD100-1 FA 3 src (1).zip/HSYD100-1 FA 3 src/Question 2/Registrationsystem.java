/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registrationsystem;

/**
 *
 * @author S
 */
public class Registrationsystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CarReg[] carArray = new CarReg[5];

// Creating CarReg objects and storing them in a array
carArray[0] = new CarReg("Chevrolet", "Aveo", "CAA123454");
carArray[1] = new CarReg("Kia", "Picanto", "CF123547");
carArray[2] = new CarReg("Ford", "Figo", "CA235874");
carArray[3] = new CarReg("Toyota", "Fortuner", "CEY254256");
carArray[4] = new CarReg("VW", "Vivo", "CF253482");


// dispaly information using a loop
for (CarReg car : carArray) {
    car.displayInfo();
    System.out.println( );
}

        // TODO code application logic here
    }
    
}
