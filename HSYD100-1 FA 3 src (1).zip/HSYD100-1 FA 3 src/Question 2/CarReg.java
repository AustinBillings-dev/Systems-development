/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registrationsystem;

/**
 *
 * @author S
 */
public class CarReg {
    // attributes of the car reg
    private String model;
    private String make;
    private String numberPlate;
    //constructor with parameters
    public CarReg(String model,String make,String numberPlate){
    this.model = model;
    this.make = make;
    this.numberPlate= numberPlate; 
}

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getNumberPlate() {
        return numberPlate;
    }

    public void setNumberPlate(String numberPlate) {
        this.numberPlate = numberPlate;
    }
    //method to display car information
    public void displayInfo() {
System.out.println("Car Make: " + make);
System.out.println("Car Model: " + model);
System.out.println("Number Plate: " + numberPlate);
}
}
