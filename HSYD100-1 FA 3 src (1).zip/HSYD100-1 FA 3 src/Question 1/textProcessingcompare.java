/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author Future CEO
 */
// QUESTION 1.2
public class textProcessingcompare{

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        //declare 2 string objects
        String str1 = "AustinPowers";
        String str2 = "AustinPowers";
        String str3 = "AustinBillings";
        
//compare string 1 and 2 for equality
boolean areEqual1 = str1.equals(str2);
// this will be true because texts is exactly the same

boolean areEqual2 = str1.equals(str3);
// this will be false because last names of text is not the same

//display the results
System.out.println("string 1 is equal to string 2 : " + areEqual1 );
System.out.println("sting 1 is equal to string 3 : " + areEqual2 );
    }
}