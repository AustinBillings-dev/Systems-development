/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package texteditor;

/**
 *
 * @author S
 */
//question 1.3
public class TextEditor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // STRINGBUILDER
        StringBuilder stringBuilder = new StringBuilder("Studying at Boston ");
        stringBuilder.append("is fun.");
        //AFTER APPENDING
        System.out.println("After appending: " + stringBuilder.toString());
        
    StringBuffer stringBuffer = new StringBuffer("Boston so awesome");
        stringBuffer.insert(7, "is ");
        System.out.println("After inserting: " + stringBuffer.toString());
        stringBuffer.delete(10, 13);
        System.out.println("After deleting: " + stringBuffer.toString());
    }
    
}
