/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author Future CEO
 */
// QUESTION 1.1
public class textProcessing {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        Scanner scanner = new Scanner(System.in);
        // Ask user to enter text for processing
        System.out.println("Enter texts for processing : ");
        String input = scanner.nextLine();
        
        for (int i = 0 ; i < input.length(); i++){
    char ch = input.charAt(i);
    //check if character is a letter if true prints the character as a letter
    if (Character.isLetter(ch)) {
    System.out.println(":" + ch + " ' is a letter. ");
}//check if character is a digit if true prints the character as a digit
    else if (Character.isDigit(ch)){
        System.out.println(":" + ch + " ' is a digit. ");
    }//if character is not a digit nor a letter prints character is neither a letter or a digit
    else { System.out.println(":" + ch + " ' is neither a letter or a digit");
    }
        }
        
    }
}
