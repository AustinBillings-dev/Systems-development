<?php 

//Connect to the Inventory database 
try {
$pdo = new PDO(dsn: "mysql:host=localhost;dbname=Inventory", username:"root", password: "mysql");


$pdo->setAttribute( PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);


}

//catch db connection errors
catch(PDOException $e) {
    echo "Connection failed:" . $e->getMessage();
}

// Get all inventory records and catch errors
try {
 $stmt = $pdo->query("SELECT item_id, item_name, quantity, supplier, category FROM warehouse_items ORDER BY item_id");
 $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
echo "Error: Could not retrieve inventory.";
}

// Tell the browser this is a CSV file
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="inventory.csv"');

// Open output
$output = fopen('php://output', 'w');

// Add headings to CSV
fputcsv($output, ['Item ID', 'Item Name', 'Quantity', 'Supplier', 'Category']);

// Add all inventory records
foreach ($items as $item) {
fputcsv($output, [$item['item_id'], $item['item_name'], $item['quantity'], $item['supplier'], $item['category']]);
}

// Close file
fclose($output);
exit;

?>