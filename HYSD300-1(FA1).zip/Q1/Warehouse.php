<?php

//Connect to the Inventory database 
try {

$pdo = new PDO(dsn: "mysql:host=localhost;dbname=Inventory", username:"root", password: "mysql");

echo "Connected to Inventory Database!"."<br>";


$pdo->setAttribute( PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);


//catch db connection errors
} catch(PDOException $e) {

echo "Connection failed:" . $e->getMessage();
}


// Handle form actions for functionality
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

$action = $_POST['action'] ?? '';

$item_id = filter_input( type: INPUT_POST, var_name: 'item_id', filter: FILTER_VALIDATE_INT );

$item_name = htmlentities( string: trim(string: $_POST['item_name'] ?? '') );

$quantity = filter_input(type: INPUT_POST,var_name: 'quantity',filter: FILTER_VALIDATE_INT);

$supplier = htmlentities(string: trim(string: $_POST['supplier'] ?? ''));

$category = htmlentities(string: trim(string: $_POST['category'] ?? ''));


// ADD
if ($action === 'Add') {

// Check for empty fields
if ( $item_name == '' || $quantity === false || $supplier == '' || $category == '' ) {

echo "Error: Please fill in all fields.";

}

// Check if quantity is valid
elseif ($quantity <= 0) {

echo "Error: Quantity must be a positive whole number.";

}

else {

 try {

// Check if item + supplier already exists
$check = $pdo->prepare("SELECT item_id FROM warehouse_items WHERE item_name = ? AND supplier = ?");

$check->execute([$item_name, $supplier]);


if ($check->fetch()) {

echo "Error: This item from this supplier already exists.";

}

else {

 // START TRANSACTION
$pdo->beginTransaction();

// Insert into MySQL
$stmt = $pdo->prepare("INSERT INTO warehouse_items (item_name, quantity, supplier, category) VALUES (?, ?, ?, ?)");

$stmt->execute([ $item_name, $quantity, $supplier, $category ]);

// Open backup.csv
$file = fopen("backup.csv", "a");

if ($file === false) {

// Cancel database insert if backup cannot be opened
$pdo->rollBack();

echo "Error: Record was not saved because backup.csv could not be opened.";

}

else {

// Add record to backup.csv
fputcsv($file, [$item_name, $quantity, $supplier, $category]);

fclose($file);

// COMPLETE TRANSACTION
$pdo->commit();

echo "Record added successfully!";

}

}

} catch (PDOException $e) {

// Undo database changes if something goes wrong
if ($pdo->inTransaction()) { 
    $pdo->rollBack();
}

    echo "Error: Could not add record.";
}

}

}

// UPDATE
if ($action === 'Update' && $item_id && $item_name && $quantity !== false && $supplier && $category ) {

$stmt = $pdo->prepare("UPDATE warehouse_items SET item_name=?, quantity=?, supplier=?, category=? WHERE item_id=?" );

$stmt->execute([ $item_name, $quantity, $supplier, $category, $item_id ]);

echo "Record updated successfully."; }


// DELETE
if ($action === 'Delete' && $item_id) {

$stmt = $pdo->prepare("DELETE FROM warehouse_items WHERE item_id=?");

$stmt->execute([$item_id]);

echo "Record deleted successfully."; }

}


// HTML form for user to record data and search data
?>

<!DOCTYPE html>
<html>

<head>
    <title>Warehouse Form</title>
</head>

<body>

<h2>Warehouse Form</h2>

<form method="post">

<table class="form-table">

<tr>
     <td>
        <label for="item_id">Item ID (for update/delete):</label>
    </td>
            <td>
                <input type="number" name="item_id" id="item_id">
            </td>
</tr>

 <tr>
     <td>
        <label for="item_name">Item Name:</label>
    </td>
            <td>
                <input type="text" name="item_name" id="item_name" required>
            </td>
</tr>

 <tr>
     <td>
        <label for="quantity">Quantity:</label>
     </td>
            <td>
                <input type="number" name="quantity" id="quantity">
            </td>
 </tr>

<tr>
    <td>
        <label for="supplier">Supplier:</label>
    </td>
            <td>
                <input type="text" name="supplier" id="supplier" required>
            </td>
</tr>

 <tr>
    <td>
        <label for="category">Category:</label>
     </td>
            <td>
                <select name="category" id="category">

                    <option value="">-- Select Category --</option>
                    <option value="Stationery">Stationery</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Furniture">Furniture</option>
                    <option value="Clothing">Clothing</option>
                    <option value="Food">Food</option>

                </select>
         </td>
</tr>

        <tr>
            <td colspan="2">

                <input type="submit" name="action" value="Add">

                <input type="submit" name="action" value="Update">

                <input type="submit" name="action" value="Delete">

            </td>
        </tr>

    </table>

</form>


<br>

<h2>Search by Supplier</h2>

<form method="get" action="search.php">

    <table class="form-table">

        <tr>
            <td>
                <label for="search_supplier">Supplier:</label>
            </td>

            <td>
                <input
                    type="text"
                    name="supplier"
                    id="search_supplier"
                    required
                >
            </td>
        </tr>

        <tr>
            <td colspan="2">

                <input type="submit" value="Search">

            </td>
        </tr>

    </table>

</form>


<h2>Export Inventory</h2>

<form method="get" action="export.php">

    <input type="submit" value="Export Full Inventory to CSV">

</form>


</body>
</html>
