<?php 

//Connect to the Inventory database 
try {
$pdo = new PDO(dsn: "mysql:host=localhost;dbname=Inventory", username:"root", password: "mysql");
echo "Connected to Inventory Database!"."<br>";
}

//catch db connection errors
catch(PDOException $e) {
echo "Connection failed:" . $e->getMessage();
}

// Get supplier entered by user
$supplier = trim($_GET['supplier'] ?? '');

$results = [];

// Search if supplier was entered
if ($supplier != '') {

try {

$stmt = $pdo->prepare(
"SELECT item_id, item_name, quantity, supplier, category FROM warehouse_items WHERE supplier LIKE ?");
$stmt->execute(["%" . $supplier . "%"]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
echo "Error: Could not search inventory.";
}
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Search Inventory</title>

</head>

<body>

<h2>Search by Supplier</h2>

<form method="get" action="search.php">

    <label for="supplier">Supplier:</label>

    <input
        type="text"
        name="supplier"
        id="supplier"
        value="<?= htmlspecialchars($supplier) ?>"
        required
    >

    <input type="submit" value="Search">

</form>


<?php if ($supplier != ''): ?>

    <h3>
        Search Results for:
        <?= htmlspecialchars($supplier) ?>
    </h3>


    <?php if (count($results) > 0): ?>

        <table border="1" cellpadding="8">

            <tr>
                <th>Item ID</th>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Supplier</th>
                <th>Category</th>
            </tr>

            <?php foreach ($results as $row): ?>

                <tr>

                    <td>
                        <?= htmlspecialchars($row['item_id']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($row['item_name']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($row['quantity']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($row['supplier']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($row['category']) ?>
                    </td>

                </tr>

            <?php endforeach; ?>

        </table>

    <?php else: ?>

        <p>No records found for this supplier.</p>

    <?php endif; ?>

<?php endif; ?>


<br>

<a href="Warehouse.php">Back to Warehouse Form</a>

</body>

</html>