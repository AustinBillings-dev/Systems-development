
<!DOCTYPE html>
<html>

<head>
    <title>Passenger Booking Form</title>

    <style>
        table {
            border-collapse: separate;
            border-spacing: 0 10px;
        }

        td {
            padding-right: 15px;
        }

        input[type="text"],
        input[type="number"] {
            padding: 5px;
            width: 200px;
        }

        input[type="submit"] {
            padding: 5px 12px;
            margin-top: 5px;
        }

        .links {
            margin-top: 15px;
        }

        .links a {
            display: block;
            margin-bottom: 8px;
        }
    </style>

</head>

<body>

<h2>Passenger Booking Form</h2>

<form method="post" action="add_booking.php">

    <table>

        <!-- Passenger Name -->
        <tr>
            <td>
                <label for="passenger_name">Passenger Name:</label>
            </td>

            <td>
                <input type="text"
                       name="passenger_name"
                       id="passenger_name"
                       required
                       maxlength="100"
                       pattern="[A-Za-z ]+"
                       title="Please enter letters and spaces only">
            </td>
        </tr>

        <!-- Destination -->
        <tr>
            <td>
                <label for="destination">Destination:</label>
            </td>

            <td>
                <input type="text"
                       name="destination"
                       id="destination"
                       required
                       maxlength="100"
                       pattern="[A-Za-z ]+"
                       title="Please enter letters and spaces only">
            </td>
        </tr>

        <!-- Fare -->
        <tr>
            <td>
                <label for="fare">Fare:</label>
            </td>

            <td>
                <input type="number"
                       name="fare"
                       id="fare"
                       required
                       min="0"
                       step="0.01"
                       title="Please enter a valid fare">
            </td>
        </tr>

        <!-- Submit Button -->
        <tr>
            <td></td>

            <td>
                <input type="submit"
                       name="action"
                       value="Add Booking">
            </td>
        </tr>

    </table>

</form>

<div class="links">

    <a href="view_bookings.php">View All Bookings</a>

    <a href="search_bookings.php">Search by Destination</a>

    <a href="export_bookings.php">Export to CSV</a>

</div>

</body>

</html>
