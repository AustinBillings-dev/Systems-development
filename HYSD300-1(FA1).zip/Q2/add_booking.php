<?php

require_once "dbconn.php";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $action = $_POST['action'] ?? '';

    // Capture and clean passenger name
    $passenger_name = trim($_POST['passenger_name'] ?? '');

    // Capture and clean destination
    $destination = trim($_POST['destination'] ?? '');

    // Capture fare
    $fare = filter_input(
        INPUT_POST,
        'fare',
        FILTER_VALIDATE_FLOAT
    );


    // ADD BOOKING
    if ($action === 'Add Booking') {

        // Check for empty fields
        if (
            $passenger_name === '' ||
            $destination === '' ||
            $fare === false ||
            $fare === null
        ) {

            echo "<h3 style='color:red;'>Error: Please fill in all fields.</h3>";

            echo "<a href='booking.html'>Back to Booking Form</a>";

        }

        // Check if fare is valid
        elseif ($fare < 0) {

            echo "<h3 style='color:red;'>Error: Fare must be a valid positive number.</h3>";

            echo "<a href='booking.html'>Back to Booking Form</a>";

        }

        else {

            try {

                // Check if booking already exists
                $check = $pdo->prepare(
                    "SELECT booking_id
                     FROM bookings
                     WHERE passenger_name = ?
                     AND destination = ?
                     AND fare = ?"
                );

                $check->execute([
                    $passenger_name,
                    $destination,
                    $fare
                ]);


                // Duplicate found
                if ($check->fetch()) {

                    echo "<h3 style='color:red;'>Error: This booking already exists.</h3>";

                    echo "<a href='booking.html'>Back to Booking Form</a>";

                }

                else {

                    // Insert booking into database
                    $stmt = $pdo->prepare(
                        "INSERT INTO bookings
                        (passenger_name, destination, fare)
                        VALUES (?, ?, ?)"
                    );

                    $stmt->execute([
                        $passenger_name,
                        $destination,
                        $fare
                    ]);


                    // Get the new booking ID
                    $booking_id = $pdo->lastInsertId();


                    // Save booking to backup.txt
                    $backup = fopen("backup.txt", "a");

                    if ($backup) {

                        $date = date("Y-m-d H:i:s");

                        fwrite(
                            $backup,
                            "Booking ID: " . $booking_id .
                            " | Passenger: " . $passenger_name .
                            " | Destination: " . $destination .
                            " | Fare: R " . number_format($fare, 2) .
                            " | Date: " . $date .
                            PHP_EOL
                        );

                        fclose($backup);

                    }


                    // Successful entry message
                    echo "<h2 style='color:green;'>Booking Added Successfully!</h2>";

                    echo "<p><b>Booking ID:</b> " . htmlspecialchars($booking_id) . "</p>";

                    echo "<p><b>Passenger Name:</b> " . htmlspecialchars($passenger_name) . "</p>";

                    echo "<p><b>Destination:</b> " . htmlspecialchars($destination) . "</p>";

                    echo "<p><b>Fare:</b> R " . number_format($fare, 2) . "</p>";

                    echo "<br>";

                    echo "<a href='booking.html'>Back to Booking Form</a>";

                    echo "<br><br>";

                    echo "<a href='view_bookings.php'>View All Bookings</a>";

                }

            } catch (PDOException $e) {

                echo "<h3 style='color:red;'>Error: Could not add record.</h3>";

                echo "<a href='booking.html'>Back to Booking Form</a>";

            }

        }

    }

}

?>
