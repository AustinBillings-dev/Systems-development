<?php

require_once "dbconn.php";

// Fare threshold
$threshold = 500;


// Delete booking
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $booking_id = filter_input(
        INPUT_POST,
        'booking_id',
        FILTER_VALIDATE_INT
    );

    if ($booking_id === false || $booking_id === null || $booking_id <= 0) {

        echo "Error: Invalid booking ID.";

    } else {

        try {

            // Delete booking using booking ID
            $stmt = $pdo->prepare(
                "DELETE FROM bookings WHERE booking_id = ?"
            );

            $stmt->execute([$booking_id]);

            if ($stmt->rowCount() > 0) {

                echo "Booking deleted successfully.";

            } else {

                echo "Error: Booking not found.";

            }

        } catch (PDOException $e) {

            echo "Error: Could not delete booking.";

        }
    }
}


// Show all bookings
function show_bookings($pdo, $threshold): void {

    try {

        // Retrieve all booking records
        $stmt = $pdo->query("SELECT * FROM bookings");

        // Store records in an array
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);


        // Check if no records exist
        if (count($bookings) == 0) {

            echo "No booking records found.";
            
            echo "<br><br>";
            echo "<a href='booking.html'>Back to Booking Form</a>";

            return;

        }


        // Variables for calculations
        $total_fare = 0;
        $highest_fare = 0;


        echo "<h2>Booking Records</h2>";

        // Dynamic HTML table
        echo "<table border='1' cellpadding='8'>";

        echo "<tr>
                <th>ID</th>
                <th>Passenger Name</th>
                <th>Destination</th>
                <th>Fare</th>
                <th>Action</th>
              </tr>";


        // Loop through the array
        foreach ($bookings as $row) {

            // Validate fare
            if (!is_numeric($row['fare']) || $row['fare'] < 0) {

                echo "Error: Invalid fare found in booking.";
                continue;

            }


            // Calculate total fare
            $total_fare += $row['fare'];


            // Find highest fare
            if ($row['fare'] > $highest_fare) {

                $highest_fare = $row['fare'];

            }


            // Safely display database information
            $id = htmlspecialchars($row['booking_id']);
            $name = htmlspecialchars($row['passenger_name']);
            $destination = htmlspecialchars($row['destination']);
            $fare = number_format((float)$row['fare'], 2);


            // Conditional formatting
            if ($row['fare'] > $threshold) {

                $fare_display = "<b style='color:red;'>R $fare</b>";

            } else {

                $fare_display = "R $fare";

            }


            // Display booking row
            echo "<tr>
                    <td>$id</td>
                    <td>$name</td>
                    <td>$destination</td>
                    <td>$fare_display</td>

                    <td>
                        <form method='post'
                              onsubmit=\"return confirm('Are you sure you want to delete this booking?');\">

                            <input type='hidden'
                                   name='booking_id'
                                   value='$id'>

                            <input type='submit'
                                   value='Delete'>

                        </form>
                    </td>

                  </tr>";

        }


        echo "</table>";


        // Calculate average fare
        $average_fare = $total_fare / count($bookings);


        // Summary Report
        echo "<h3>Summary Report</h3>";

        echo "Total Fare: R " .
             number_format($total_fare, 2) .
             "<br>";

        echo "Average Fare: R " .
             number_format($average_fare, 2) .
             "<br>";

        echo "Highest Fare: R " .
             number_format($highest_fare, 2) .
             "<br>";


        // Back to booking form
        echo "<br><br>";

        echo "<a href='booking.html'>Back to Booking Form</a>";

    } catch (PDOException $e) {

        // Database error handling
        echo "Error: Could not retrieve booking records.";

        echo "<br><br>";
        echo "<a href='booking.html'>Back to Booking Form</a>";

    }

}


// Display bookings
show_bookings($pdo, $threshold);

?>
