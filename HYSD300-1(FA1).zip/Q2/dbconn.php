<?php

//Connect to the transport_management database 

try {

$pdo = new PDO(dsn: "mysql:host=localhost;dbname=transport_management", username:"root", password: "mysql");


$pdo->setAttribute( PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);


//catch db connection errors
} catch(PDOException $e) {

echo "Connection failed:" . $e->getMessage();
}
?>