<?php

require_once "dbconn.php";

// Get destination entered by user
$destination = trim($_GET['destination'] ?? '');

$results = [];

// Check if destination was entered
if ($destination != '') {

    try {

        // Search bookings by destination
        $stmt = $pdo->prepare(
            "SELECT booking_id, passenger_name, destination, fare
             FROM bookings
             WHERE destination LIKE ?"
        );

        $stmt->execute([
            "%" . $destination . "%"
        ]);

        // Store results in an array
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {

        echo "Error: Could not search bookings.";

    }

}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Search Results</title>

</head>

<body>

<?php if ($destination != ''): ?>

    <h2>
        Search Results for: <?= htmlspecialchars($destination) ?>
    </h2>


    <?php if (count($results) > 0): ?>

        <table border="1" cellpadding="8">

            <tr>

                <th>Booking ID</th>
                <th>Passenger Name</th>
                <th>Destination</th>
                <th>Fare</th>

            </tr>


            <?php foreach ($results as $row): ?>

                <tr>

                    <td>
                        <?= htmlspecialchars($row['booking_id']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($row['passenger_name']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($row['destination']) ?>
                    </td>

                    <td>
                        R <?= number_format((float)$row['fare'], 2) ?>
                    </td>

                </tr>

            <?php endforeach; ?>

        </table>


    <?php else: ?>

        <p>No bookings found for this destination.</p>

    <?php endif; ?>


<?php else: ?>

    <p>Please enter a destination to search.</p>

<?php endif; ?>


<br>

<a href="search_bookings.php">Search Again</a>

<br><br>

<a href="booking.html">Back to Booking Form</a>

<br><br>

<a href="view_bookings.php">View All Bookings</a>

</body>

</html>
