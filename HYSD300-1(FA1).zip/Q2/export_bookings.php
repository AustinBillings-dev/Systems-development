<?php

// Connect to the transport database
require_once "dbconn.php";

// Get all booking records
try {

    $stmt = $pdo->query(
        "SELECT booking_id, passenger_name, destination, fare
         FROM bookings
         ORDER BY booking_id"
    );

    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    echo "Error: Could not retrieve bookings.";
    exit;

}


// Tell the browser this is a CSV file
header('Content-Type: text/csv');

header(
    'Content-Disposition: attachment; filename="bookings.csv"'
);


// Open output
$output = fopen('php://output', 'w');


// Add headings to CSV
fputcsv(
    $output,
    ['Booking ID', 'Passenger Name', 'Destination', 'Fare']
);


// Add all booking records
foreach ($bookings as $booking) {

    fputcsv(
        $output,
        [
            $booking['booking_id'],
            $booking['passenger_name'],
            $booking['destination'],
            $booking['fare']
        ]
    );

}


// Close file
fclose($output);

exit;

?>
