<!DOCTYPE html>
<html>

<head>
    <title>Search Bookings</title>
</head>

<body>

<h2>Search Bookings by Destination</h2>

<form method="get" action="search_results.php">

    <label for="destination">Destination:</label>

    <input
        type="text"
        name="destination"
        id="destination"
        required
        maxlength="100"
        pattern="[A-Za-z ]+"
        title="Please enter letters and spaces only"
    >

    <input type="submit" value="Search">

</form>

<br>

<a href="booking.html">Back to Booking Form</a>

<br><br>

<a href="view_bookings.php">View All Bookings</a>

</body>

</html>
