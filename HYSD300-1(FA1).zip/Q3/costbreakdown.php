<?php

// Connect to the earthmoving_company database

$conn = new mysqli( "localhost", "root", "mysql", "earthmoving_company");


// Check database connection

if ($conn->connect_error) {

    echo "Connection failed: " . $conn->connect_error;

}


// Initialise error message

$error = "";


// Check if the form was submitted using POST

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    $error = "Invalid request. Please use the booking form.";

}


// Get values submitted from the booking form

$customer_code = $_POST['customer_code'] ?? "";

$distance = $_POST['distance'] ?? "";


// Validate customer code

if (empty($error) && empty($customer_code)) {

    $error = "Please select a customer.";

}


// Validate distance

elseif (empty($error) && empty($distance)) {

    $error = "Please enter the roadwork distance.";

}


// Check if distance is numeric

elseif (empty($error) && !is_numeric($distance)) {

    $error = "Roadwork distance must be a number.";

}


// Check if distance is greater than zero

elseif (empty($error) && $distance <= 0) {

    $error = "Roadwork distance must be greater than zero.";

}


// Continue only if there are no validation errors

if (empty($error)) {


    // Convert distance to a number

    $distance = (float)$distance;


    
    // RETRIEVE CUSTOMER DETAILS


    try {

        // Prepare SQL statement

        $stmt = $conn->prepare("SELECT customer_code, name, city FROM customers WHERE customer_code = ?" );


        // Check if statement was prepared

        if (!$stmt) {

            throw new Exception("Could not prepare the customer query.");

        }


        // Bind customer code

        // "s" means customer_code is a string

        $stmt->bind_param("s", $customer_code);


        // Execute the prepared statement

        $stmt->execute();


        // Get query result

        $result = $stmt->get_result();


        // Fetch customer details

        $customer = $result->fetch_assoc();


        // Check if customer exists

        if (!$customer) {

            $error = "Customer not found. Please select a valid customer.";

        }


        // Close prepared statement

        $stmt->close();


    } catch (Exception $e) {

        $error = "Error retrieving customer information.";

    }


    
    // CALCULATE PROJECT COST
    

    if (empty($error)) {


        // Distance charge R45 per kilometre

        $distanceCharge = $distance * 45;


        // Labour cost 5% of distance charge

        $labourCost = $distanceCharge * 0.05;


        // Work time 4.5 hours per kilometre

        $workHours = $distance * 4.5;


        // Hourly fee R1250 per hour

        $hourlyCost = $workHours * 1250;


        // Total before VAT

        $subtotal = $distanceCharge  + $labourCost + $hourlyCost;


        // VAT 15% of subtotal

        $vat = $subtotal * 0.15;


        // Final project cost

        $totalCost = $subtotal + $vat;

    }

}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Project Cost Breakdown</title>


    <style>

        body {

            font-family: Arial, sans-serif;

            margin: 40px;

            background-color: white;

            color: black;

        }


        h1 {

            font-size: 28px;

            margin-bottom: 25px;

        }


        .error {

            color: red;

            font-weight: bold;

            margin-bottom: 20px;

        }


        .customer-details {

            margin-bottom: 25px;

        }


        .customer-details p {

            margin: 8px 0;

        }


        table {

            border-collapse: collapse;

            width: 600px;

            max-width: 100%;

        }


        th,
        td {

            border: 1px solid black;

            padding: 10px;

        }


        th {

            background-color: #eeeeee;

            text-align: left;

        }


        td:last-child,
        th:last-child {

            text-align: right;

        }


        .total {

            font-size: 18px;

            font-weight: bold;

            background-color: #eeeeee;

        }


        .back-button {

            display: inline-block;

            margin-top: 20px;

            padding: 7px 12px;

            color: black;

            border: 1px solid black;

            text-decoration: none;

        }

    </style>

</head>


<body>


<?php if (!empty($error)): ?>


    <!-- Display error message -->

    <h1>Project Cost Breakdown</h1>


    <div class="error">

        <?php echo htmlspecialchars($error); ?>

    </div>


    <a href="earthmoving_booking.php" class="back-button">

        Back to Booking Form

    </a>


<?php else: ?>


    <!-- Page heading -->

    <h1>Project Cost Breakdown</h1>


    <!-- Customer information -->

    <div class="customer-details">


        <p>

            <strong>Customer Code:</strong>

            <?php

            echo htmlspecialchars($customer['customer_code']);

            ?>

        </p>


        <p>

            <strong>Customer Name:</strong>

            <?php

            echo htmlspecialchars($customer['name']);

            ?>

        </p>


        <p>

            <strong>City:</strong>

            <?php

            echo htmlspecialchars($customer['city']);

            ?>

        </p>


        <p>

            <strong>Distance:</strong>

            <?php

            echo number_format($distance, 2);

            ?>

            km

        </p>


    </div>


    <!-- Project Cost Breakdown -->

    <table>


        <tr>

            <th>

                Description

            </th>


            <th>

                Amount

            </th>

        </tr>


        <tr>

            <td>

                Distance Charge (R45/km)

            </td>


            <td>

                R <?php echo number_format($distanceCharge, 2); ?>

            </td>

        </tr>


        <tr>

            <td>

                Labour Cost (5%)

            </td>


            <td>

                R <?php echo number_format($labourCost, 2); ?>

            </td>

        </tr>


        <tr>

            <td>

                Total Work Time

            </td>


            <td>

                <?php echo number_format($workHours, 2); ?> hours

            </td>

        </tr>


        <tr>

            <td>

                Hourly Cost (R1250/hour)

            </td>


            <td>

                R <?php echo number_format($hourlyCost, 2); ?>

            </td>

        </tr>


        <tr>

            <td>

                Total Cost Before VAT

            </td>


            <td>

                R <?php echo number_format($subtotal, 2); ?>

            </td>

        </tr>


        <tr>

            <td>

                VAT (15%)

            </td>


            <td>

                R <?php echo number_format($vat, 2); ?>

            </td>

        </tr>


        <tr class="total">

            <td>

                Total Project Cost

            </td>


            <td>

                R <?php echo number_format($totalCost, 2); ?>

            </td>

        </tr>


    </table>


    <a href="earthmoving_booking.php" class="back-button">

        Back to Booking Form

    </a>


<?php endif; ?>


</body>

</html>


<?php

// Close database connection

$conn->close();

?>
