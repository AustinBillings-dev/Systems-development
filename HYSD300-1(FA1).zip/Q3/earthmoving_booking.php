<?php

// Connect to the earthmoving_company database

$conn = new mysqli( "localhost", "root", "mysql", "earthmoving_company");


// Check database connection

if ($conn->connect_error) {

    echo "Connection failed: " . $conn->connect_error;

}


// Retrieve customers from the customers table

$sql = "SELECT customer_code, name FROM customers ORDER BY customer_code";

$result = $conn->query($sql);


// Check if customers were retrieved successfully

if (!$result) {

    echo "Error retrieving customers: " . $conn->error;

}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Earthmoving Booking Form</title>


    <style>

        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: white;
            color: black;
        }


        h1 {
            font-size: 28px;
            margin-bottom: 25px;
        }


        .form-group {
            margin-bottom: 18px;
        }


        label {
            display: inline-block;
            width: 150px;
            font-size: 16px;
        }


        select,
        input[type="number"] {

            padding: 5px;

            font-size: 14px;

            width: 200px;

        }


        button {

            padding: 6px 12px;

            font-size: 14px;

            cursor: pointer;

        }

    </style>

</head>


<body>


    <h1>Earthmoving Booking Form</h1>


    <form action="costbreakdown.php" method="POST">


        <!-- Customer selection -->

        <div class="form-group">

            <label for="customer_code">
                Customer:
            </label>


            <select
                name="customer_code"
                id="customer_code"
                required
            >


                <option value="">
                    -- Select Customer --
                </option>


                <?php

                // Display customers retrieved from the database

                while ($row = $result->fetch_assoc()) {

                ?>


                    <option
                        value="<?php echo htmlspecialchars($row['customer_code']); ?>"
                    >

                        <?php

                        echo htmlspecialchars($row['customer_code']);

                        ?>

                        -

                        <?php

                        echo htmlspecialchars($row['name']);

                        ?>

                    </option>


                <?php

                }

                ?>


            </select>

        </div>


        <!-- Roadwork distance -->

        <div class="form-group">

            <label for="distance">
                Distance (km):
            </label>


            <input
                type="number"
                name="distance"
                id="distance"
                step="0.01"
                min="0.01"
                required
            >

        </div>


        <!-- Submit button -->

        <button type="submit">

            Calculate Project Cost

        </button>


    </form>


</body>

</html>


<?php

// Close database connection

$conn->close();

?>
