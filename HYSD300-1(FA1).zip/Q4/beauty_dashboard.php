<?php

// Start the session
session_start();


// Display errors while developing
error_reporting(E_ALL);
ini_set('display_errors', 1);


// -----------------------------------------
// CHECK IF USER IS LOGGED IN
// -----------------------------------------

if (!isset($_SESSION['client_id'])) {

    header("Location: beauty_login.php");
    exit;
}


// -----------------------------------------
// CONNECT TO DATABASE
// -----------------------------------------

$conn = new mysqli(
    "localhost",
    "root",
    "mysql",
    "beauty_parlour"
);


// Check database connection
if ($conn->connect_error) {

    die(
        "Database connection failed. Please try again later."
    );

}


// -----------------------------------------
// GET LOGGED-IN CLIENT
// -----------------------------------------

$stmt = $conn->prepare(
    "SELECT client_id, name, email, phone, city
     FROM clients
     WHERE client_id = ?"
);


// Check if statement was prepared
if (!$stmt) {

    die(
        "Unable to retrieve your profile. Please try again."
    );

}


$stmt->bind_param(
    "i",
    $_SESSION['client_id']
);


// Execute query
if (!$stmt->execute()) {

    die(
        "Unable to retrieve your profile. Please try again."
    );

}


$result = $stmt->get_result();


// Get client details
$client = $result->fetch_assoc();


// Check if client still exists
if (!$client) {

    session_destroy();

    header("Location: beauty_login.php");
    exit;
}


// Close statement
$stmt->close();


// -----------------------------------------
// GET UPCOMING APPOINTMENTS
// -----------------------------------------

$stmt = $conn->prepare(
    "SELECT appointment_id, appointment_date, service, status
     FROM appointments
     WHERE client_id = ?
     AND appointment_date >= CURDATE()
     ORDER BY appointment_date ASC"
);


// Check if statement was prepared
if (!$stmt) {

    die(
        "Unable to retrieve appointments. Please try again."
    );

}


$stmt->bind_param(
    "i",
    $_SESSION['client_id']
);


// Execute query
if (!$stmt->execute()) {

    die(
        "Unable to retrieve appointments. Please try again."
    );

}


$appointments = $stmt->get_result();

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Beauty Parlour Dashboard
    </title>


    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: white;

            color: black;

            margin: 0;

            padding: 40px;

        }


        .container {

            width: 900px;

            max-width: 100%;

            margin: auto;

        }


        h1 {

            text-align: center;

            margin-bottom: 10px;

        }


        .welcome {

            text-align: center;

            font-size: 18px;

            margin-bottom: 30px;

        }


        /* Navigation */

        .menu {

            display: flex;

            justify-content: center;

            gap: 10px;

            margin-bottom: 30px;

            flex-wrap: wrap;

        }


        .menu a {

            padding: 10px 18px;

            border: 1px solid black;

            text-decoration: none;

            color: black;

            background-color: #eeeeee;

        }


        .menu a:hover {

            background-color: #dddddd;

        }


        /* Profile */

        .profile {

            border: 1px solid black;

            padding: 20px;

            margin-bottom: 30px;

        }


        .profile h2 {

            margin-top: 0;

        }


        .profile p {

            margin: 8px 0;

        }


        .profile-link {

            display: inline-block;

            margin-top: 10px;

            color: black;

            font-weight: bold;

        }


        /* Appointments */

        .appointments {

            margin-top: 20px;

        }


        table {

            width: 100%;

            border-collapse: collapse;

            margin-top: 15px;

        }


        th,
        td {

            border: 1px solid black;

            padding: 10px;

            text-align: left;

        }


        th {

            background-color: #eeeeee;

        }


        /* Status */

        .booked {

            color: green;

            font-weight: bold;

        }


        .cancelled {

            color: red;

            font-weight: bold;

        }


        /* Appointment actions */

        .action {

            margin-right: 8px;

            color: black;

        }


        /* Logout */

        .logout {

            text-align: center;

            margin-top: 30px;

        }


        .logout a {

            color: red;

            font-weight: bold;

        }


    </style>

</head>


<body>


<div class="container">


    <!-- ---------------------------------
         DASHBOARD HEADING
    ---------------------------------- -->

    <h1>

        Beauty Parlour Dashboard

    </h1>


    <!-- ---------------------------------
         WELCOME MESSAGE
    ---------------------------------- -->

    <div class="welcome">

        Welcome,

        <strong>

            <?php

            echo htmlspecialchars(
                $client['name']
            );

            ?>

        </strong>

        to the Beauty Parlour!

    </div>


    <!-- ---------------------------------
         NAVIGATION MENU
    ---------------------------------- -->

    <div class="menu">


        <a href="view_appointments.php">

            View Appointments

        </a>


        <a href="add_appointment.php">

            Add Appointment

        </a>


        <a href="update_appointment.php">

            Update Appointment

        </a>


        <a href="cancel_appointment.php">

            Cancel Appointment

        </a>


    </div>


    <!-- ---------------------------------
         CLIENT PROFILE
    ---------------------------------- -->

    <div class="profile">

        <h2>

            My Profile

        </h2>


        <p>

            <strong>Name:</strong>

            <?php

            echo htmlspecialchars(
                $client['name']
            );

            ?>

        </p>


        <p>

            <strong>Email:</strong>

            <?php

            echo htmlspecialchars(
                $client['email']
            );

            ?>

        </p>


        <p>

            <strong>Phone:</strong>

            <?php

            echo htmlspecialchars(
                $client['phone'] ?? 'Not provided'
            );

            ?>

        </p>


        <p>

            <strong>City:</strong>

            <?php

            echo htmlspecialchars(
                $client['city'] ?? 'Not provided'
            );

            ?>

        </p>


        <!-- Profile update link -->

        <a
            class="profile-link"
            href="profile.php"
        >

            Edit My Profile

        </a>

    </div>


    <!-- ---------------------------------
         UPCOMING APPOINTMENTS
    ---------------------------------- -->

    <div class="appointments">


        <h2>

            My Upcoming Appointments

        </h2>


        <?php

        // Check whether appointments exist

        if ($appointments->num_rows > 0):

        ?>


            <table>


                <tr>

                    <th>
                        Appointment ID
                    </th>

                    <th>
                        Date
                    </th>

                    <th>
                        Service
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Actions
                    </th>

                </tr>


                <?php

                // ---------------------------------
                // LOOP THROUGH APPOINTMENTS
                // ---------------------------------

                while (
                    $appointment =
                    $appointments->fetch_assoc()
                ):

                ?>


                    <tr>


                        <!-- Appointment ID -->

                        <td>

                            <?php

                            echo htmlspecialchars(
                                $appointment['appointment_id']
                            );

                            ?>

                        </td>


                        <!-- Appointment Date -->

                        <td>

                            <?php

                            echo htmlspecialchars(
                                $appointment['appointment_date']
                            );

                            ?>

                        </td>


                        <!-- Service -->

                        <td>

                            <?php

                            echo htmlspecialchars(
                                $appointment['service']
                            );

                            ?>

                        </td>


                        <!-- Status -->

                        <td>

                            <?php

                            // Selection structure

                            if (
                                $appointment['status']
                                === 'Booked'
                            ) {

                                echo
                                '<span class="booked">
                                    Booked
                                </span>';

                            }

                            elseif (
                                $appointment['status']
                                === 'Cancelled'
                            ) {

                                echo
                                '<span class="cancelled">
                                    Cancelled
                                </span>';

                            }

                            else {

                                echo htmlspecialchars(
                                    $appointment['status']
                                );

                            }

                            ?>

                        </td>


                        <!-- Actions -->

                        <td>


                            <?php

                            // Only booked appointments
                            // can be changed or cancelled

                            if (
                                $appointment['status']
                                === 'Booked'
                            ):

                            ?>


                                <a
                                    class="action"
                                    href="update_appointment.php?id=<?php
                                    echo
                                    $appointment['appointment_id'];
                                    ?>"
                                >

                                    Update

                                </a>


                                |


                                <a
                                    class="action"
                                    href="cancel_appointment.php?id=<?php
                                    echo
                                    $appointment['appointment_id'];
                                    ?>"
                                >

                                    Cancel

                                </a>


                            <?php

                            else:

                            ?>


                                <span class="cancelled">

                                    No actions available

                                </span>


                            <?php

                            endif;

                            ?>


                        </td>


                    </tr>


                <?php

                endwhile;

                ?>


            </table>


        <?php

        else:

        ?>


            <p>

                You currently have no upcoming appointments.

            </p>


            <p>

                <a href="add_appointment.php">

                    Book a new appointment

                </a>

            </p>


        <?php

        endif;

        ?>


    </div>


    <!-- ---------------------------------
         LOGOUT
    ---------------------------------- -->

    <div class="logout">

        <a href="beauty_logout.php">

            Log Out

        </a>

    </div>


</div>


</body>

</html>


<?php

// Close statement
$stmt->close();


// Close database connection
$conn->close();

?>
