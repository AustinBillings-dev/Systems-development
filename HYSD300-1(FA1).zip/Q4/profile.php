<?php

// Start session
session_start();

// Display errors while developing
error_reporting(E_ALL);
ini_set('display_errors', 1);


// -----------------------------------------
// CHECK LOGIN
// -----------------------------------------

if (!isset($_SESSION['client_id'])) {

    header("Location: beauty_login.php");
    exit;
}


// -----------------------------------------
// CONNECT TO DATABASE
// -----------------------------------------

$conn = new mysqli(
    "localhost",
    "root",
    "mysql",
    "beauty_parlour"
);


// Check database connection
if ($conn->connect_error) {

    die("Database connection failed. Please try again later.");

}


// -----------------------------------------
// VARIABLES
// -----------------------------------------

$error = "";
$success = "";

$name = "";
$email = "";
$phone = "";
$city = "";

$client_id = $_SESSION['client_id'];


// -----------------------------------------
// GET CURRENT PROFILE
// -----------------------------------------

$stmt = $conn->prepare(
    "SELECT name, email, phone, city
     FROM clients
     WHERE client_id = ?"
);


if (!$stmt) {

    die("Unable to retrieve profile.");

}


$stmt->bind_param(
    "i",
    $client_id
);


$stmt->execute();


$result = $stmt->get_result();


$client = $result->fetch_assoc();


$stmt->close();


// Check client exists
if (!$client) {

    session_destroy();

    header("Location: beauty_login.php");
    exit;
}


// Load existing values
$name = $client['name'];
$email = $client['email'];
$phone = $client['phone'];
$city = $client['city'];


// -----------------------------------------
// PROCESS PROFILE UPDATE
// -----------------------------------------

if ($_SERVER["REQUEST_METHOD"] === "POST") {


    $name = trim($_POST['name'] ?? "");

    $email = trim($_POST['email'] ?? "");

    $phone = trim($_POST['phone'] ?? "");

    $city = trim($_POST['city'] ?? "");


    // -----------------------------------------
    // VALIDATE INPUT
    // -----------------------------------------

    if (empty($name)) {

        $error = "Please enter your name.";

    }

    elseif (empty($email)) {

        $error = "Please enter your email address.";

    }

    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    }

    elseif (empty($phone)) {

        $error = "Please enter your phone number.";

    }

    elseif (empty($city)) {

        $error = "Please enter your city.";

    }


    // -----------------------------------------
    // UPDATE PROFILE
    // -----------------------------------------

    if (empty($error)) {


        try {


            $stmt = $conn->prepare(
                "UPDATE clients
                 SET name = ?,
                     email = ?,
                     phone = ?,
                     city = ?
                 WHERE client_id = ?"
            );


            if (!$stmt) {

                throw new Exception(
                    "Unable to prepare profile update."
                );

            }


            $stmt->bind_param(
                "ssssi",
                $name,
                $email,
                $phone,
                $city,
                $client_id
            );


            if ($stmt->execute()) {


                $success =
                    "Your profile was updated successfully.";


                // Update session values

                $_SESSION['name'] = $name;

                $_SESSION['email'] = $email;

            }

            else {

                $error =
                    "Unable to update your profile.";

            }


            $stmt->close();


        } catch (Exception $e) {

            // Handle duplicate email
            if ($conn->errno == 1062) {

                $error =
                    "That email address is already registered.";

            }

            else {

                $error =
                    "A database error occurred. Please try again.";

            }

        }

    }

}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>My Profile - Beauty Parlour</title>


    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: white;

            color: black;

            margin: 0;

            padding: 40px;

        }


        .container {

            width: 500px;

            max-width: 100%;

            margin: auto;

        }


        h1 {

            text-align: center;

        }


        .box {

            border: 1px solid black;

            padding: 25px;

            margin-top: 25px;

        }


        .form-group {

            margin-bottom: 18px;

        }


        label {

            display: block;

            font-weight: bold;

            margin-bottom: 6px;

        }


        input {

            width: 100%;

            padding: 9px;

            box-sizing: border-box;

            border: 1px solid #777;

        }


        button {

            width: 100%;

            padding: 10px;

            background-color: black;

            color: white;

            border: none;

            cursor: pointer;

        }


        button:hover {

            background-color: #333;

        }


        .error {

            color: red;

            font-weight: bold;

            text-align: center;

            margin-bottom: 15px;

        }


        .success {

            color: green;

            font-weight: bold;

            text-align: center;

            margin-bottom: 15px;

        }


        .links {

            text-align: center;

            margin-top: 25px;

        }


        .links a {

            color: black;

            margin: 0 8px;

        }

    </style>

</head>


<body>


<div class="container">


    <h1>

        My Profile

    </h1>


    <div class="box">


        <?php if (!empty($error)): ?>

            <div class="error">

                <?php

                echo htmlspecialchars($error);

                ?>

            </div>

        <?php endif; ?>


        <?php if (!empty($success)): ?>

            <div class="success">

                <?php

                echo htmlspecialchars($success);

                ?>

            </div>

        <?php endif; ?>


        <form method="POST">


            <!-- Name -->

            <div class="form-group">

                <label for="name">

                    Name:

                </label>


                <input
                    type="text"
                    id="name"
                    name="name"
                    value="<?php echo htmlspecialchars($name); ?>"
                    required
                >

            </div>


            <!-- Email -->

            <div class="form-group">

                <label for="email">

                    Email:

                </label>


                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?php echo htmlspecialchars($email); ?>"
                    required
                >

            </div>


            <!-- Phone -->

            <div class="form-group">

                <label for="phone">

                    Phone:

                </label>


                <input
                    type="text"
                    id="phone"
                    name="phone"
                    value="<?php echo htmlspecialchars($phone); ?>"
                    required
                >

            </div>


            <!-- City -->

            <div class="form-group">

                <label for="city">

                    City:

                </label>


                <input
                    type="text"
                    id="city"
                    name="city"
                    value="<?php echo htmlspecialchars($city); ?>"
                    required
                >

            </div>


            <button type="submit">

                Update Profile

            </button>


        </form>


        <div class="links">

            <a href="beauty_dashboard.php">

                Dashboard

            </a>


            |


            <a href="view_appointments.php">

                View Appointments

            </a>

        </div>


    </div>

</div>


</body>

</html>


<?php

$conn->close();

?>
