<?php

// Start session
session_start();

// Display errors while developing
error_reporting(E_ALL);
ini_set('display_errors', 1);


// -----------------------------------------
// CHECK LOGIN
// -----------------------------------------

if (!isset($_SESSION['client_id'])) {

    header("Location: beauty_login.php");
    exit;
}


// -----------------------------------------
// CONNECT TO DATABASE
// -----------------------------------------

$conn = new mysqli(
    "localhost",
    "root",
    "mysql",
    "beauty_parlour"
);


// Check database connection
if ($conn->connect_error) {

    die("Database connection failed. Please try again later.");

}


// -----------------------------------------
// VARIABLES
// -----------------------------------------

$error = "";
$success = "";

$selected_id = "";
$appointment_date = "";
$service = "";


// -----------------------------------------
// UPDATE APPOINTMENT
// -----------------------------------------

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $selected_id = $_POST['appointment_id'] ?? "";

    $appointment_date = trim(
        $_POST['appointment_date'] ?? ""
    );

    $service = trim(
        $_POST['service'] ?? ""
    );


    // -----------------------------------------
    // VALIDATE FIELDS
    // -----------------------------------------

    if (empty($selected_id)) {

        $error = "Please select an appointment.";

    }

    elseif (empty($appointment_date)) {

        $error = "Please select an appointment date.";

    }

    elseif (empty($service)) {

        $error = "Please enter a service.";

    }


    // -----------------------------------------
    // UPDATE IF NO ERRORS
    // -----------------------------------------

    if (empty($error)) {

        $stmt = $conn->prepare(
            "UPDATE appointments
             SET appointment_date = ?, service = ?
             WHERE appointment_id = ?
             AND client_id = ?
             AND status = 'Booked'"
        );


        if (!$stmt) {

            $error = "Unable to update appointment.";

        }

        else {

            $stmt->bind_param(
                "ssii",
                $appointment_date,
                $service,
                $selected_id,
                $_SESSION['client_id']
            );


            if ($stmt->execute()) {

                if ($stmt->affected_rows > 0) {

                    $success = "Appointment updated successfully.";

                }

                else {

                    $error =
                        "Appointment could not be updated. " .
                        "It may already be cancelled.";

                }

            }

            else {

                $error = "Unable to update appointment.";

            }


            $stmt->close();

        }

    }

}


// -----------------------------------------
// GET USER'S APPOINTMENTS
// -----------------------------------------

$stmt = $conn->prepare(
    "SELECT appointment_id, appointment_date, service, status
     FROM appointments
     WHERE client_id = ?
     ORDER BY appointment_date ASC"
);


if (!$stmt) {

    die("Unable to retrieve appointments.");

}


$stmt->bind_param(
    "i",
    $_SESSION['client_id']
);


$stmt->execute();


$appointments = $stmt->get_result();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Update Appointment</title>


    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: white;

            color: black;

            margin: 0;

            padding: 40px;

        }


        .container {

            width: 600px;

            max-width: 100%;

            margin: auto;

        }


        h1 {

            text-align: center;

        }


        .box {

            border: 1px solid black;

            padding: 25px;

            margin-top: 25px;

        }


        label {

            display: block;

            font-weight: bold;

            margin-top: 15px;

            margin-bottom: 5px;

        }


        select,
        input[type="date"],
        input[type="text"] {

            width: 100%;

            padding: 10px;

            box-sizing: border-box;

            border: 1px solid #777;

        }


        button {

            margin-top: 20px;

            padding: 10px 20px;

            background-color: black;

            color: white;

            border: none;

            cursor: pointer;

        }


        button:hover {

            background-color: #333;

        }


        .error {

            color: red;

            font-weight: bold;

            margin-bottom: 15px;

        }


        .success {

            color: green;

            font-weight: bold;

            margin-bottom: 15px;

        }


        .links {

            margin-top: 25px;

        }


        .links a {

            margin-right: 15px;

        }

    </style>

</head>


<body>


<div class="container">

    <h1>Update Appointment</h1>


    <?php if (!empty($error)): ?>

        <div class="error">

            <?php echo htmlspecialchars($error); ?>

        </div>

    <?php endif; ?>


    <?php if (!empty($success)): ?>

        <div class="success">

            <?php echo htmlspecialchars($success); ?>

        </div>

    <?php endif; ?>


    <div class="box">


        <form method="POST" action="update_appointment.php">


            <!-- SELECT APPOINTMENT -->

            <label for="appointment_id">

                Select Appointment:

            </label>


            <select
                name="appointment_id"
                id="appointment_id"
                required
            >

                <option value="">

                    -- Select an appointment --

                </option>


                <?php while ($appointment = $appointments->fetch_assoc()): ?>


                    <?php if ($appointment['status'] === 'Booked'): ?>


                        <option
                            value="<?php
                            echo $appointment['appointment_id'];
                            ?>"
                        >

                            <?php

                            echo htmlspecialchars(
                                $appointment['appointment_date']
                            );

                            ?>

                            -

                            <?php

                            echo htmlspecialchars(
                                $appointment['service']
                            );

                            ?>

                            - Booked

                        </option>


                    <?php endif; ?>


                <?php endwhile; ?>


            </select>


            <!-- DATE -->

            <label for="appointment_date">

                New Appointment Date:

            </label>


            <input
                type="date"
                id="appointment_date"
                name="appointment_date"
                value="<?php
                    echo htmlspecialchars($appointment_date);
                ?>"
                required
            >


            <!-- SERVICE -->

            <label for="service">

                New Service:

            </label>


            <input
                type="text"
                id="service"
                name="service"
                value="<?php
                    echo htmlspecialchars($service);
                ?>"
                placeholder="Enter service"
                required
            >


            <button type="submit">

                Update Appointment

            </button>


        </form>


        <div class="links">

            <a href="beauty_dashboard.php">

                Back to Dashboard

            </a>


            <a href="view_appointments.php">

                View Appointments

            </a>

        </div>


    </div>

</div>


</body>

</html>


<?php

$stmt->close();

$conn->close();

?>

