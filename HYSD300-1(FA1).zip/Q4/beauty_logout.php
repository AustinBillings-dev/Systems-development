<?php
session_start();
session_destroy();
header(header: "Location: beauty_login.php");
exit;
?>
