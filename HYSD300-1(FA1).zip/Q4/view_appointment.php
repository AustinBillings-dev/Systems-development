<?php

// Start the session
session_start();

// Display errors while developing
error_reporting(E_ALL);
ini_set('display_errors', 1);


// Check if the user is logged in
if (!isset($_SESSION['client_id'])) {

    header("Location: beauty_login.php");
    exit;
}


// Connect to the database
$conn = new mysqli(
    "localhost",
    "root",
    "mysql",
    "beauty_parlour"
);


// Check database connection
if ($conn->connect_error) {

    die("Database connection failed. Please try again later.");
}


// Get the logged-in client's ID
$client_id = $_SESSION['client_id'];


// Retrieve this client's appointments
$sql = "SELECT appointment_id, appointment_date, service, status
        FROM appointments
        WHERE client_id = ?
        ORDER BY appointment_date ASC";


$stmt = $conn->prepare($sql);


// Check if SQL statement was prepared
if (!$stmt) {

    die("Unable to retrieve appointments. Please try again later.");
}


// Bind client ID
$stmt->bind_param("i", $client_id);


// Execute query
$stmt->execute();


// Get results
$result = $stmt->get_result();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>View Appointments - Beauty Parlour</title>


    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: white;

            color: black;

            margin: 0;

            padding: 40px;

        }


        .container {

            width: 900px;

            max-width: 100%;

            margin: auto;

        }


        h1 {

            text-align: center;

            margin-bottom: 10px;

        }


        .welcome {

            text-align: center;

            margin-bottom: 25px;

        }


        .menu {

            text-align: center;

            margin-bottom: 30px;

        }


        .menu a {

            display: inline-block;

            padding: 10px 15px;

            margin: 5px;

            border: 1px solid black;

            background-color: #eeeeee;

            color: black;

            text-decoration: none;

        }


        .menu a:hover {

            background-color: #dddddd;

        }


        table {

            width: 100%;

            border-collapse: collapse;

            margin-top: 20px;

        }


        th,
        td {

            border: 1px solid black;

            padding: 10px;

            text-align: left;

        }


        th {

            background-color: #eeeeee;

        }


        .booked {

            color: green;

            font-weight: bold;

        }


        .cancelled {

            color: red;

            font-weight: bold;

        }


        .message {

            text-align: center;

            padding: 15px;

            border: 1px solid black;

            margin-top: 20px;

        }


        .actions a {

            color: black;

            margin-right: 8px;

        }


        .logout {

            text-align: center;

            margin-top: 30px;

        }


        .logout a {

            color: red;

            font-weight: bold;

        }

    </style>

</head>


<body>


<div class="container">


    <h1>

        My Appointments

    </h1>


    <div class="welcome">

        Welcome,

        <strong>

            <?php

            echo htmlspecialchars($_SESSION['name']);

            ?>

        </strong>

    </div>


    <!-- Navigation -->

    <div class="menu">

        <a href="beauty_dashboard.php">

            Dashboard

        </a>


        <a href="add_appointment.php">

            Add Appointment

        </a>


        <a href="update_appointment.php">

            Update Appointment

        </a>


        <a href="profile.php">

            My Profile

        </a>

    </div>


    <?php if ($result->num_rows > 0): ?>


        <table>

            <tr>

                <th>

                    Appointment ID

                </th>

                <th>

                    Date

                </th>

                <th>

                    Service

                </th>

                <th>

                    Status

                </th>

                <th>

                    Actions

                </th>

            </tr>


            <?php

            // Display appointments using a loop

            while ($appointment = $result->fetch_assoc()):

            ?>


                <tr>


                    <td>

                        <?php

                        echo htmlspecialchars(
                            $appointment['appointment_id']
                        );

                        ?>

                    </td>


                    <td>

                        <?php

                        echo htmlspecialchars(
                            $appointment['appointment_date']
                        );

                        ?>

                    </td>


                    <td>

                        <?php

                        echo htmlspecialchars(
                            $appointment['service']
                        );

                        ?>

                    </td>


                    <td>

                        <?php

                        if ($appointment['status'] === 'Booked') {

                            echo '<span class="booked">Booked</span>';

                        } else {

                            echo '<span class="cancelled">Cancelled</span>';

                        }

                        ?>

                    </td>


                    <td class="actions">


                        <?php

                        if ($appointment['status'] === 'Booked'):

                        ?>


                            <!-- Update appointment -->

                            <a href="update_appointment.php?id=<?php
                                echo $appointment['appointment_id'];
                            ?>">

                                Update

                            </a>


                            |


                            <!-- Cancel appointment -->

                            <a href="cancel_appointment.php?id=<?php
                                echo $appointment['appointment_id'];
                            ?>">

                                Cancel

                            </a>


                        <?php else: ?>


                            <span class="cancelled">

                                Cancelled

                            </span>


                        <?php endif; ?>


                    </td>


                </tr>


            <?php endwhile; ?>


        </table>


    <?php else: ?>


        <div class="message">

            <p>

                You currently have no appointments.

            </p>


            <p>

                <a href="add_appointment.php">

                    Add your first appointment

                </a>

            </p>

        </div>


    <?php endif; ?>


    <!-- Logout -->

    <div class="logout">

        <a href="beauty_logout.php">

            Log Out

        </a>

    </div>


</div>


</body>

</html>


<?php

// Close statement
$stmt->close();


// Close database connection
$conn->close();

?>
