<?php

// Start session
session_start();

// Display errors while developing
error_reporting(E_ALL);
ini_set('display_errors', 1);


// -----------------------------------------
// CHECK LOGIN
// -----------------------------------------

if (!isset($_SESSION['client_id'])) {

    header("Location: beauty_login.php");
    exit;
}


// -----------------------------------------
// CONNECT TO DATABASE
// -----------------------------------------

$conn = new mysqli(
    "localhost",
    "root",
    "mysql",
    "beauty_parlour"
);


// Check database connection
if ($conn->connect_error) {

    die("Database connection failed. Please try again later.");

}


// -----------------------------------------
// VARIABLES
// -----------------------------------------

$error = "";
$success = "";


// -----------------------------------------
// CANCEL APPOINTMENT
// -----------------------------------------

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $appointment_id = $_POST['appointment_id'] ?? "";


    // Check if appointment was selected
    if (empty($appointment_id)) {

        $error = "Please select an appointment to cancel.";

    }

    else {

        // Update status instead of deleting the appointment
        $stmt = $conn->prepare(
            "UPDATE appointments
             SET status = 'Cancelled'
             WHERE appointment_id = ?
             AND client_id = ?
             AND status = 'Booked'"
        );


        if (!$stmt) {

            $error = "Unable to cancel appointment.";

        }

        else {

            $stmt->bind_param(
                "ii",
                $appointment_id,
                $_SESSION['client_id']
            );


            if ($stmt->execute()) {

                if ($stmt->affected_rows > 0) {

                    $success =
                        "Appointment cancelled successfully.";

                }

                else {

                    $error =
                        "Appointment could not be cancelled. " .
                        "It may already be cancelled.";

                }

            }

            else {

                $error = "Unable to cancel appointment.";

            }


            $stmt->close();

        }

    }

}


// -----------------------------------------
// GET USER'S BOOKED APPOINTMENTS
// -----------------------------------------

$stmt = $conn->prepare(
    "SELECT appointment_id, appointment_date, service
     FROM appointments
     WHERE client_id = ?
     AND status = 'Booked'
     ORDER BY appointment_date ASC"
);


if (!$stmt) {

    die("Unable to retrieve appointments.");

}


$stmt->bind_param(
    "i",
    $_SESSION['client_id']
);


$stmt->execute();


$appointments = $stmt->get_result();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Cancel Appointment</title>


    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: white;

            color: black;

            margin: 0;

            padding: 40px;

        }


        .container {

            width: 600px;

            max-width: 100%;

            margin: auto;

        }


        h1 {

            text-align: center;

        }


        .box {

            border: 1px solid black;

            padding: 25px;

            margin-top: 25px;

        }


        label {

            display: block;

            font-weight: bold;

            margin-bottom: 8px;

        }


        select {

            width: 100%;

            padding: 10px;

            box-sizing: border-box;

            border: 1px solid #777;

        }


        button {

            margin-top: 20px;

            padding: 10px 20px;

            background-color: red;

            color: white;

            border: none;

            cursor: pointer;

        }


        button:hover {

            background-color: darkred;

        }


        .error {

            color: red;

            font-weight: bold;

            margin-bottom: 15px;

        }


        .success {

            color: green;

            font-weight: bold;

            margin-bottom: 15px;

        }


        .links {

            margin-top: 25px;

        }


        .links a {

            margin-right: 15px;

        }

    </style>

</head>


<body>


<div class="container">


    <h1>

        Cancel Appointment

    </h1>


    <?php if (!empty($error)): ?>

        <div class="error">

            <?php echo htmlspecialchars($error); ?>

        </div>

    <?php endif; ?>


    <?php if (!empty($success)): ?>

        <div class="success">

            <?php echo htmlspecialchars($success); ?>

        </div>

    <?php endif; ?>


    <div class="box">


        <?php if ($appointments->num_rows > 0): ?>


            <form
                method="POST"
                action="cancel_appointment.php"
                onsubmit="return confirm('Are you sure you want to cancel this appointment?');"
            >


                <label for="appointment_id">

                    Select Appointment to Cancel:

                </label>


                <select
                    name="appointment_id"
                    id="appointment_id"
                    required
                >

                    <option value="">

                        -- Select an appointment --

                    </option>


                    <?php while ($appointment = $appointments->fetch_assoc()): ?>


                        <option
                            value="<?php
                            echo $appointment['appointment_id'];
                            ?>"
                        >

                            <?php

                            echo htmlspecialchars(
                                $appointment['appointment_date']
                            );

                            ?>

                            -

                            <?php

                            echo htmlspecialchars(
                                $appointment['service']
                            );

                            ?>

                        </option>


                    <?php endwhile; ?>


                </select>


                <button type="submit">

                    Cancel Appointment

                </button>


            </form>


        <?php else: ?>


            <p>

                You have no booked appointments to cancel.

            </p>


        <?php endif; ?>


        <div class="links">

            <a href="beauty_dashboard.php">

                Back to Dashboard

            </a>


            <a href="view_appointments.php">

                View Appointments

            </a>

        </div>


    </div>


</div>


</body>

</html>


<?php

$stmt->close();

$conn->close();

?>
