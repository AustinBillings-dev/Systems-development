<?php

// Start the session
session_start();

// Show errors while testing
error_reporting(E_ALL);
ini_set('display_errors', 1);


// Connect to the database
$conn = new mysqli(
    "localhost",
    "root",
    "mysql",
    "beauty_parlour"
);


// Check database connection
if ($conn->connect_error) {

    die("Database connection failed: " . $conn->connect_error);

}


// Variables
$error = "";
$email = "";


// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Get values from form
    $email = trim($_POST['email'] ?? "");
    $password = $_POST['password'] ?? "";


    // Validate input
    if (empty($email)) {

        $error = "Please enter your email address.";

    }

    elseif (empty($password)) {

        $error = "Please enter your password.";

    }

    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    }


    // Continue if there are no errors
    if (empty($error)) {

        try {

            // Prepared statement
            $sql = "SELECT client_id, email, password, name
                    FROM clients
                    WHERE email = ?";

            $stmt = $conn->prepare($sql);


            // Check prepared statement
            if (!$stmt) {

                throw new Exception(
                    "SQL prepare failed: " . $conn->error
                );

            }


            // Bind email
            $stmt->bind_param("s", $email);


            // Execute
            $stmt->execute();


            // Get result
            $result = $stmt->get_result();


            // Get client
            $client = $result->fetch_assoc();


            // Check if client exists
            if (!$client) {

                $error = "Invalid email or password.";

            }


            // Verify password
            elseif (
                !password_verify(
                    $password,
                    $client['password']
                )
            ) {

                $error = "Invalid email or password.";

            }


            // Login successful
            else {

                // Regenerate session ID
                session_regenerate_id(true);


                // Store user details
                $_SESSION['client_id'] = $client['client_id'];

                $_SESSION['email'] = $client['email'];

                $_SESSION['name'] = $client['name'];


                // Remember Me
                if (isset($_POST['remember'])) {

                    // Remember email for 7 days
                    setcookie(
                        "remember_email",
                        $email,
                        time() + (86400 * 7),
                        "/"
                    );

                }

                else {

                    // Remove remembered email
                    setcookie(
                        "remember_email",
                        "",
                        time() - 3600,
                        "/"
                    );

                }


                // Close statement
                $stmt->close();


                // Redirect to dashboard
                header("Location: beauty_dashboard.php");

                exit;

            }


            // Close statement
            $stmt->close();


        } catch (Exception $e) {

            $error =
                "Database error: " . $e->getMessage();

        }

    }

}


// Load remembered email
if (
    empty($email)
    &&
    isset($_COOKIE['remember_email'])
) {

    $email = $_COOKIE['remember_email'];

}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Beauty Parlor Login</title>


    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: white;

            color: black;

            margin: 0;

            min-height: 100vh;

            display: flex;

            justify-content: center;

            align-items: center;

        }


        .login-container {

            width: 350px;

            border: 1px solid black;

            padding: 30px;

            background-color: white;

            box-sizing: border-box;

        }


        h2 {

            text-align: center;

            margin-top: 0;

            margin-bottom: 25px;

        }


        .form-group {

            margin-bottom: 18px;

        }


        label {

            display: block;

            margin-bottom: 6px;

            font-weight: bold;

        }


        input[type="email"],
        input[type="password"] {

            width: 100%;

            padding: 9px;

            box-sizing: border-box;

            border: 1px solid #777;

        }


        .remember {

            margin-bottom: 18px;

        }


        .remember label {

            display: inline;

            font-weight: normal;

        }


        button {

            width: 100%;

            padding: 10px;

            background-color: black;

            color: white;

            border: none;

            cursor: pointer;

        }


        button:hover {

            background-color: #333;

        }


        .error {

            color: red;

            text-align: center;

            font-weight: bold;

            margin-bottom: 15px;

        }

    </style>

</head>


<body>


<div class="login-container">

    <h2>Beauty Parlor Login</h2>


    <?php if (!empty($error)): ?>

        <div class="error">

            <?php

            echo htmlspecialchars($error);

            ?>

        </div>

    <?php endif; ?>


    <form
        method="POST"
        action="beauty_login.php"
    >


        <!-- Email -->

        <div class="form-group">

            <label for="email">

                Email:

            </label>

            <input
                type="email"
                id="email"
                name="email"
                value="<?php
                    echo htmlspecialchars($email);
                ?>"
                required
            >

        </div>


        <!-- Password -->

        <div class="form-group">

            <label for="password">

                Password:

            </label>

            <input
                type="password"
                id="password"
                name="password"
                required
            >

        </div>


        <!-- Remember Me -->

        <div class="remember">

            <input
                type="checkbox"
                id="remember"
                name="remember"

                <?php

                if (isset($_COOKIE['remember_email'])) {

                    echo "checked";

                }

                ?>
            >

            <label for="remember">

                Remember Me

            </label>

        </div>


        <!-- Login button -->

        <button type="submit">

            Login

        </button>


    </form>

</div>


</body>

</html>


<?php

$conn->close();

?>