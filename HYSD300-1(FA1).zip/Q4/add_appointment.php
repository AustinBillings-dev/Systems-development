<?php

// Start the session
session_start();

// Show errors while developing
error_reporting(E_ALL);
ini_set('display_errors', 1);


// -----------------------------------------
// CHECK IF USER IS LOGGED IN
// -----------------------------------------

if (!isset($_SESSION['client_id'])) {

    header("Location: beauty_login.php");
    exit;
}


// -----------------------------------------
// CONNECT TO DATABASE
// -----------------------------------------

$conn = new mysqli(
    "localhost",
    "root",
    "mysql",
    "beauty_parlour"
);


// Check database connection
if ($conn->connect_error) {

    die("Database connection failed. Please try again later.");
}


// -----------------------------------------
// VARIABLES
// -----------------------------------------

$error = "";
$success = "";

$appointment_date = "";
$service = "";


// -----------------------------------------
// PROCESS FORM
// -----------------------------------------

if ($_SERVER["REQUEST_METHOD"] === "POST") {


    // Get form values

    $appointment_date = trim(
        $_POST['appointment_date'] ?? ""
    );

    $service = trim(
        $_POST['service'] ?? ""
    );


    // -----------------------------------------
    // VALIDATE REQUIRED FIELDS
    // -----------------------------------------

    if (empty($appointment_date)) {

        $error = "Please select an appointment date.";

    }

    elseif (empty($service)) {

        $error = "Please select a service.";

    }


    // -----------------------------------------
    // CHECK DATE
    // -----------------------------------------

    elseif ($appointment_date < date("Y-m-d")) {

        $error = "Please select today or a future date.";

    }


    // -----------------------------------------
    // INSERT APPOINTMENT
    // -----------------------------------------

    if (empty($error)) {

        try {

            $sql = "INSERT INTO appointments
                    (client_id, appointment_date, service, status)
                    VALUES (?, ?, ?, 'Booked')";


            $stmt = $conn->prepare($sql);


            // Check prepare statement

            if (!$stmt) {

                throw new Exception(
                    "Unable to prepare appointment."
                );

            }


            // Get logged-in client's ID

            $client_id = $_SESSION['client_id'];


            // Bind values

            $stmt->bind_param(
                "iss",
                $client_id,
                $appointment_date,
                $service
            );


            // Execute

            if ($stmt->execute()) {

                $success =
                    "Your appointment has been booked successfully.";

                // Clear form

                $appointment_date = "";
                $service = "";

            }

            else {

                $error =
                    "Unable to book the appointment. Please try again.";

            }


            $stmt->close();


        } catch (Exception $e) {

            $error =
                "A database error occurred. Please try again.";

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Add Appointment - Beauty Parlour</title>


    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: white;

            color: black;

            margin: 0;

            padding: 40px;

        }


        .container {

            width: 500px;

            max-width: 100%;

            margin: auto;

        }


        h1 {

            text-align: center;

        }


        .box {

            border: 1px solid black;

            padding: 25px;

            margin-top: 25px;

        }


        .form-group {

            margin-bottom: 20px;

        }


        label {

            display: block;

            font-weight: bold;

            margin-bottom: 7px;

        }


        input[type="date"],
        select {

            width: 100%;

            padding: 10px;

            box-sizing: border-box;

            border: 1px solid #777;

        }


        button {

            width: 100%;

            padding: 10px;

            background-color: black;

            color: white;

            border: none;

            cursor: pointer;

        }


        button:hover {

            background-color: #333;

        }


        .error {

            color: red;

            font-weight: bold;

            text-align: center;

            margin-bottom: 15px;

        }


        .success {

            color: green;

            font-weight: bold;

            text-align: center;

            margin-bottom: 15px;

        }


        .links {

            text-align: center;

            margin-top: 25px;

        }


        .links a {

            color: black;

            text-decoration: none;

            margin: 0 8px;

        }


        .links a:hover {

            text-decoration: underline;

        }

    </style>

</head>


<body>


<div class="container">


    <h1>

        Book an Appointment

    </h1>


    <div class="box">


        <?php if (!empty($error)): ?>

            <div class="error">

                <?php

                echo htmlspecialchars($error);

                ?>

            </div>

        <?php endif; ?>


        <?php if (!empty($success)): ?>

            <div class="success">

                <?php

                echo htmlspecialchars($success);

                ?>

            </div>

        <?php endif; ?>


        <form method="POST">


            <!-- Appointment Date -->

            <div class="form-group">

                <label for="appointment_date">

                    Appointment Date:

                </label>


                <input
                    type="date"
                    id="appointment_date"
                    name="appointment_date"
                    value="<?php
                        echo htmlspecialchars(
                            $appointment_date
                        );
                    ?>"
                    min="<?php echo date('Y-m-d'); ?>"
                    required
                >

            </div>


            <!-- Service -->

            <div class="form-group">

                <label for="service">

                    Select Service:

                </label>


                <select
                    id="service"
                    name="service"
                    required
                >

                    <option value="">

                        -- Select a service --

                    </option>


                    <option
                        value="Haircut"
                        <?php
                        if ($service === "Haircut") {
                            echo "selected";
                        }
                        ?>
                    >

                        Haircut

                    </option>


                    <option
                        value="Hair Styling"
                        <?php
                        if ($service === "Hair Styling") {
                            echo "selected";
                        }
                        ?>
                    >

                        Hair Styling

                    </option>


                    <option
                        value="Manicure"
                        <?php
                        if ($service === "Manicure") {
                            echo "selected";
                        }
                        ?>
                    >

                        Manicure

                    </option>


                    <option
                        value="Pedicure"
                        <?php
                        if ($service === "Pedicure") {
                            echo "selected";
                        }
                        ?>
                    >

                        Pedicure

                    </option>


                    <option
                        value="Facial"
                        <?php
                        if ($service === "Facial") {
                            echo "selected";
                        }
                        ?>
                    >

                        Facial

                    </option>


                    <option
                        value="Makeup"
                        <?php
                        if ($service === "Makeup") {
                            echo "selected";
                        }
                        ?>
                    >

                        Makeup

                    </option>


                </select>

            </div>


            <!-- Submit -->

            <button type="submit">

                Book Appointment

            </button>


        </form>


        <!-- Navigation -->

        <div class="links">

            <a href="beauty_dashboard.php">

                Dashboard

            </a>


            |


            <a href="view_appointments.php">

                View Appointments

            </a>

        </div>


    </div>


</div>


</body>

</html>


<?php

$conn->close();

?>
