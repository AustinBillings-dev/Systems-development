<?php

$conn = new mysqli(
    "localhost",
    "root",
    "mysql",
    "beauty_parlour"
);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Test user details
$email = "tia@gmail.com";
$password = "Password123";
$name = "Test User";
$phone = "0712345678";
$city = "Johannesburg";

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert the user
$stmt = $conn->prepare(
    "INSERT INTO clients (email, password, name, phone, city)
     VALUES (?, ?, ?, ?, ?)"
);

$stmt->bind_param(
    "sssss",
    $email,
    $hashed_password,
    $name,
    $phone,
    $city
);

if ($stmt->execute()) {

    echo "Test user created successfully.<br>";
    echo "Email: test@gmail.com<br>";
    echo "Password: Password123";

} else {

    echo "Error creating test user: " . $stmt->error;

}

$stmt->close();
$conn->close();

?>
