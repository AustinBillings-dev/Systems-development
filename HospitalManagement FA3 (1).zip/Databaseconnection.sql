CREATE DATABASE hospital;
USE hospital;
create table patients(
patient_id INT AUTO_INCREMENT PRIMARY KEY,
full_name VARCHAR(100) NOT NULL,
next_of_kin VARCHAR(100) NOT NULL,
address VARCHAR(255) NOT NULL );