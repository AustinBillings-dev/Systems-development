/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package databaseconnection;

import java.sql.*;
import java.util.Scanner;


/**
 *
 * @author S
 */
public class HospitalManagement {

    /**
     * @param args the command line arguments
     */
    
    //jdbc variables
    private static final String URL = "jdbc:mysql://localhost:3306/hospital";
    private static final String USER ="root";
    private static final String PASSWORD ="Reekae77";
    
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        // declare variables for database connection
        
        
        try(Connection conMySQLConnectionString = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","Reekae77")){
            System.out.println("Connected to HospitalDB successfully! ");
            
            int choice;
            do{
                System.out.println("============================");
                System.out.println("Patient database menu: ");
                System.out.println("============================");
                System.out.println("1.View Patients");
                System.out.println("2.Add Patient");
                System.out.println("3.Delete Patient");
                System.out.println("4.Exit");
                System.out.println("============================");
                System.out.println("Select an option: ");
                
             choice = scanner.nextInt() ;
             scanner.nextLine();//consume new line
             
             switch(choice){
                 case 1: viewPatients(conMySQLConnectionString);
                 break;
                 case 2: addPatient(conMySQLConnectionString, scanner);
                 break;
                 case 3: deletePatients(conMySQLConnectionString, scanner);
                 break;
                 case 4: System.out.println("Exiting program... Goodbye!! ");
                 break;
                 default: System.out.println("Please select a valid choice from 1-4");
             }
             System.out.println();
             
            } while(choice != 4);
            
        } catch(SQLException e){
                
                System.out.println("Database connection error: " + e.getMessage());
             }
            }
    
        //1.view all patient records
        private static void viewPatients(Connection conMySQLConnectionString){
            try{
                String sql = "SELECT * FROM patients";
                Statement stmt = conMySQLConnectionString.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                
                System.out.println("Patient Records: ");
                System.out.println("============================");
                System.out.printf("%-5s | %-20s | %-20s | %-30s%n", "ID", "Full Name", "Next of Kin", "Address");
                System.out.println("============================");
                
                
                while(rs.next()){
                    
                System.out.printf("%-5s | %-20s | %-20s | %-30s%n",
               rs.getInt("PatientID"),
                 rs.getString("FullName"),
                 rs.getString("Next_of_Kin"),
                 rs.getString("Address"));
                }
                
                System.out.println("------------------------");
                
            }catch (SQLException e){
                System.out.println("error viewing records: " + e.getMessage());
            }
            } 
        
        //2.add new patient record
        private static void addPatient(Connection conMySQLConnectionString,Scanner scanner){
            
            try {
                System.out.println("Enter Full Name: ");
                String fullName = scanner.nextLine();
                System.out.println("Enter Next of Kin: ");
                String nextOfKin = scanner.nextLine();
                System.out.println("Enter Address: ");
                String address = scanner.nextLine();
                
                String sql = "INSERT INTO patients (FullName, Next_of_kin, Address) Values(?,?,?)";
            
            PreparedStatement pstm = conMySQLConnectionString.prepareStatement(sql);
            pstm.setString(1,fullName);
            pstm.setString(2,nextOfKin);
            pstm.setString(3, address);
            
        int rows = pstm.executeUpdate();
        
        if(rows > 0){
            
            System.out.println("Patient added successfully! ");
        }
            
            } catch(SQLException e){
                
                System.out.println("Error adding patient. " + e.getMessage());
            }
        }
        
        //delete a patient record
        private static void deletePatients(Connection conMySQLConnectionString , Scanner scanner){
        try {
             System.out.println("Enter Patient ID to delete: ");
             int id = scanner.nextInt();
             scanner.nextLine();//consume new line
             
             String sql = "DELETE FROM patients WHERE PatientID = ?";
             PreparedStatement pstm = conMySQLConnectionString.prepareStatement(sql);
             pstm.setInt(1, id);
             
        int rows = pstm.executeUpdate();
        
        if(rows > 0){
            System.out.println("Patient record deleted successfully! ");
            
        } else {
            System.out.println("No Patient has been with ID " + id);
        }
        } catch (SQLException e){
            System.out.println("Error deleting record: " + e.getMessage());
        }
        }
}

        
       
    